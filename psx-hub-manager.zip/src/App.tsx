import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Database, 
  Package, 
  Activity, 
  Users, 
  Settings, 
  Disc, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  Search,
  ChevronRight,
  Cpu,
  Globe,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

// --- Types ---

interface Service {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
  uptime: string;
  dependencies: string[];
}

interface Game {
  id: string;
  title: string;
  stock: number;
  rentals: number;
  status: string;
}

interface Stats {
  totalDiscs: number;
  activeRentals: number;
  warehouseUtilization: string;
  activeServices: number;
  degradedServices: number;
  downServices: number;
}

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
      active 
        ? 'bg-ps-blue/20 text-white border-l-4 border-ps-blue' 
        : 'text-gray-500 hover:bg-white/5 hover:text-gray-300'
    }`}
  >
    <Icon size={20} />
    <span className="text-sm font-medium">{label}</span>
  </button>
);

const StatCard = ({ label, value, subtext, icon: Icon, trend }: any) => (
  <div className="glass-panel p-5 rounded-xl flex flex-col gap-2">
    <div className="flex justify-between items-start">
      <div className="p-2 bg-white/5 rounded-lg">
        <Icon size={20} className="text-ps-blue" />
      </div>
      {trend && (
        <span className={`text-xs font-mono ${trend > 0 ? 'text-green-400' : 'text-red-400'}`}>
          {trend > 0 ? '+' : ''}{trend}%
        </span>
      )}
    </div>
    <div className="mt-2">
      <p className="text-xs text-gray-500 uppercase tracking-wider font-mono">{label}</p>
      <p className="text-2xl font-bold mt-1">{value}</p>
      {subtext && <p className="text-[10px] text-gray-600 font-mono mt-1">{subtext}</p>}
    </div>
  </div>
);

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [services, setServices] = useState<Service[]>([]);
  const [catalog, setCatalog] = useState<Game[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [hoveredService, setHoveredService] = useState<Service | null>(null);

  // Filters & Sorting
  const [filterDomain, setFilterDomain] = useState('All');
  const [filterLanguage, setFilterLanguage] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [maxLatency, setMaxLatency] = useState(200);
  const [sortBy, setSortBy] = useState('id');
  const [searchTerm, setSearchTerm] = useState('');

  const domains = ['All', ...new Set(services.map(s => s.domain))];
  const languages = ['All', ...new Set(services.map(s => s.language))];

  const filteredServices = services
    .filter(s => (filterDomain === 'All' || s.domain === filterDomain))
    .filter(s => (filterLanguage === 'All' || s.language === filterLanguage))
    .filter(s => (filterStatus === 'All' || s.status === filterStatus))
    .filter(s => s.latency <= maxLatency)
    .filter(s => 
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      s.id.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === 'latency') return b.latency - a.latency;
      if (sortBy === 'uptime') return parseFloat(b.uptime) - parseFloat(a.uptime);
      return a.id.localeCompare(b.id);
    });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [healthRes, catalogRes, statsRes] = await Promise.all([
          fetch('/api/system/health'),
          fetch('/api/catalog'),
          fetch('/api/stats')
        ]);
        
        setServices(await healthRes.json());
        setCatalog(await catalogRes.json());
        setStats(await statsRes.json());
      } catch (error) {
        console.error("Failed to fetch data", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 10000); // Refresh every 10s
    return () => clearInterval(interval);
  }, []);

  const renderDashboard = () => (
    <div className="flex flex-col gap-6 overflow-y-auto h-full pr-2">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Inventory" value={stats?.totalDiscs.toLocaleString()} subtext="Across 12 Global Hubs" icon={Disc} trend={2.4} />
        <StatCard label="Active Rentals" value={stats?.activeRentals.toLocaleString()} subtext="89% Return Rate" icon={Package} trend={-1.2} />
        <StatCard label="System Health" value={`${stats?.activeServices}/1000`} subtext={`${stats?.downServices} Critical Failures`} icon={Activity} />
        <StatCard label="Warehouse Load" value={stats?.warehouseUtilization} subtext="Capacity Optimization: High" icon={Layers} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-panel p-6 rounded-xl">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold flex items-center gap-2">
              <Activity size={18} className="text-ps-blue" />
              Global Distribution Traffic
            </h3>
            <div className="flex gap-2">
              <span className="flex items-center gap-1 text-[10px] text-gray-500">
                <div className="w-2 h-2 rounded-full bg-ps-blue" /> Orders
              </span>
              <span className="flex items-center gap-1 text-[10px] text-gray-500">
                <div className="w-2 h-2 rounded-full bg-ps-accent" /> Returns
              </span>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={[
                { name: '00:00', orders: 400, returns: 240 },
                { name: '04:00', orders: 300, returns: 139 },
                { name: '08:00', orders: 200, returns: 980 },
                { name: '12:00', orders: 278, returns: 390 },
                { name: '16:00', orders: 189, returns: 480 },
                { name: '20:00', orders: 239, returns: 380 },
                { name: '23:59', orders: 349, returns: 430 },
              ]}>
                <defs>
                  <linearGradient id="colorOrders" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#003791" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#003791" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                <XAxis dataKey="name" stroke="#555" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#555" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#151619', border: '1px solid #333', borderRadius: '8px' }}
                  itemStyle={{ fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="orders" stroke="#003791" fillOpacity={1} fill="url(#colorOrders)" />
                <Area type="monotone" dataKey="returns" stroke="#0072ce" fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-panel p-6 rounded-xl">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <AlertTriangle size={18} className="text-yellow-500" />
            Active Incidents
          </h3>
          <div className="flex flex-col gap-4">
            {services.filter(s => s.status !== 'healthy').slice(0, 5).map(svc => (
              <div key={svc.id} className="p-3 bg-white/5 rounded-lg border-l-2 border-red-500">
                <div className="flex justify-between items-start">
                  <p className="text-xs font-bold">{svc.name}</p>
                  <span className="text-[10px] font-mono text-gray-500 uppercase">{svc.language}</span>
                </div>
                <p className="text-[10px] text-gray-400 mt-1">Domain: {svc.domain}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex-1 h-1 bg-gray-800 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500 w-[85%]" />
                  </div>
                  <span className="text-[10px] font-mono text-red-400">CRITICAL</span>
                </div>
              </div>
            ))}
            <button className="text-[10px] text-ps-blue uppercase tracking-widest font-bold mt-2 hover:underline">
              View All 18 Incidents
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSystemHealth = () => (
    <div className="flex flex-col gap-6 h-full">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold">Microservice Mesh</h2>
          <p className="text-xs text-gray-500 font-mono">Visualizing {filteredServices.length} polyglot services across 10 domains</p>
        </div>
        <div className="flex gap-4 text-[10px] font-mono uppercase tracking-wider">
          <div className="flex items-center gap-1"><div className="w-2 h-2 bg-green-500 rounded-sm" /> Healthy</div>
          <div className="flex items-center gap-1"><div className="w-2 h-2 bg-yellow-500 rounded-sm" /> Degraded</div>
          <div className="flex items-center gap-1"><div className="w-2 h-2 bg-red-500 rounded-sm" /> Offline</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="glass-panel p-4 rounded-xl flex flex-wrap items-center gap-6">
        <div className="flex flex-col gap-1.5 min-w-[200px]">
          <label className="text-[10px] text-gray-500 uppercase font-mono tracking-widest">Search Service</label>
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" size={12} />
            <input 
              type="text" 
              placeholder="Name or ID..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-ps-dark border border-white/10 rounded pl-7 pr-2 py-1 text-xs focus:outline-none focus:border-ps-blue"
            />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-[10px] text-gray-500 uppercase font-mono tracking-widest">Domain</label>
          <select 
            value={filterDomain}
            onChange={(e) => setFilterDomain(e.target.value)}
            className="bg-ps-dark border border-white/10 rounded px-2 py-1 text-xs focus:outline-none focus:border-ps-blue"
          >
            {domains.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-[10px] text-gray-500 uppercase font-mono tracking-widest">Language</label>
          <select 
            value={filterLanguage}
            onChange={(e) => setFilterLanguage(e.target.value)}
            className="bg-ps-dark border border-white/10 rounded px-2 py-1 text-xs focus:outline-none focus:border-ps-blue"
          >
            {languages.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-[10px] text-gray-500 uppercase font-mono tracking-widest">Status</label>
          <select 
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-ps-dark border border-white/10 rounded px-2 py-1 text-xs focus:outline-none focus:border-ps-blue"
          >
            <option value="All">All Statuses</option>
            <option value="healthy">Healthy</option>
            <option value="degraded">Degraded</option>
            <option value="down">Offline</option>
          </select>
        </div>

        <div className="flex flex-col gap-1.5 flex-1 min-w-[150px]">
          <div className="flex justify-between">
            <label className="text-[10px] text-gray-500 uppercase font-mono tracking-widest">Max Latency</label>
            <span className="text-[10px] font-mono text-ps-blue">{maxLatency}ms</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max="200" 
            value={maxLatency}
            onChange={(e) => setMaxLatency(parseInt(e.target.value))}
            className="accent-ps-blue h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-[10px] text-gray-500 uppercase font-mono tracking-widest">Sort By</label>
          <select 
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-ps-dark border border-white/10 rounded px-2 py-1 text-xs focus:outline-none focus:border-ps-blue"
          >
            <option value="id">Service ID</option>
            <option value="latency">Highest Latency</option>
            <option value="uptime">Highest Uptime</option>
          </select>
        </div>
      </div>

      <div className="flex-1 glass-panel p-6 rounded-xl overflow-hidden flex flex-col gap-6">
        <div className="service-grid">
          {filteredServices.map(svc => {
            const isHovered = hoveredService?.id === svc.id;
            const isDependency = hoveredService?.dependencies.includes(svc.id);
            
            return (
              <motion.div
                key={svc.id}
                initial={{ scale: 0 }}
                animate={{ 
                  scale: isHovered ? 1.5 : isDependency ? 1.2 : 1,
                  boxShadow: isDependency ? '0 0 8px rgba(0, 114, 206, 0.8)' : 'none'
                }}
                onMouseEnter={() => setHoveredService(svc)}
                className={`aspect-square rounded-sm cursor-crosshair transition-all duration-200 ${
                  isHovered ? 'z-20 ring-2 ring-white' : 
                  isDependency ? 'z-10 animate-pulse' : 'z-0'
                } ${
                  svc.status === 'healthy' ? 'bg-green-500/40 hover:bg-green-400' :
                  svc.status === 'degraded' ? 'bg-yellow-500/60 hover:bg-yellow-400' :
                  'bg-red-500 hover:bg-red-400'
                }`}
              />
            );
          })}
          {filteredServices.length === 0 && (
            <div className="col-span-full h-32 flex items-center justify-center text-gray-600 font-mono text-xs uppercase tracking-widest">
              No services match current filters
            </div>
          )}
        </div>

        <div className="h-48 border-t border-white/5 pt-4 flex flex-col gap-4 overflow-y-auto">
          {hoveredService ? (
            <AnimatePresence mode="wait">
              <motion.div 
                key={hoveredService.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex flex-col gap-4"
              >
                <div className="flex gap-8">
                  <div className="flex flex-col gap-1">
                    <p className="text-[10px] text-gray-500 uppercase font-mono">Service ID</p>
                    <p className="text-lg font-bold font-mono">{hoveredService.id}</p>
                  </div>
                  <div className="flex flex-col gap-1">
                    <p className="text-[10px] text-gray-500 uppercase font-mono">Name</p>
                    <p className="text-lg font-bold">{hoveredService.name}</p>
                  </div>
                  <div className="flex flex-col gap-1">
                    <p className="text-[10px] text-gray-500 uppercase font-mono">Runtime</p>
                    <div className="flex items-center gap-2">
                      <Cpu size={14} className="text-ps-blue" />
                      <p className="text-lg font-bold">{hoveredService.language}</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <p className="text-[10px] text-gray-500 uppercase font-mono">Latency</p>
                    <p className="text-lg font-bold font-mono">{hoveredService.latency}ms</p>
                  </div>
                  <div className="flex flex-col gap-1">
                    <p className="text-[10px] text-gray-500 uppercase font-mono">Uptime</p>
                    <p className="text-lg font-bold font-mono text-green-400">{hoveredService.uptime}%</p>
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <p className="text-[10px] text-gray-500 uppercase font-mono tracking-widest">Direct Dependencies</p>
                  <div className="flex flex-wrap gap-2">
                    {hoveredService.dependencies.map(depId => {
                      const dep = services.find(s => s.id === depId);
                      const status = dep?.status || 'down';
                      
                      const StatusIcon = 
                        status === 'healthy' ? CheckCircle2 :
                        status === 'degraded' ? AlertTriangle : XCircle;
                      
                      const statusColor = 
                        status === 'healthy' ? 'text-green-500' :
                        status === 'degraded' ? 'text-yellow-500' : 'text-red-500';

                      const statusBorder = 
                        status === 'healthy' ? 'border-green-500/20' :
                        status === 'degraded' ? 'border-yellow-500/20' : 'border-red-500/20';

                      return (
                        <div 
                          key={depId} 
                          className={`flex items-center gap-2 px-2 py-1 bg-white/5 rounded border ${statusBorder} transition-all duration-200 hover:bg-white/10`}
                        >
                          <StatusIcon size={12} className={statusColor} />
                          <div className="flex flex-col">
                            <span className="text-[9px] font-mono leading-none">{depId}</span>
                            <span className="text-[10px] font-bold leading-tight">{dep?.name || 'Unknown'}</span>
                          </div>
                        </div>
                      );
                    })}
                    {hoveredService.dependencies.length === 0 && (
                      <p className="text-[10px] text-gray-600 italic">No direct dependencies detected</p>
                    )}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-600 italic text-sm">
              Hover over a service node to inspect telemetry and dependencies
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderCatalog = () => (
    <div className="flex flex-col gap-6 h-full">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Global Product Catalog</h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
          <input 
            type="text" 
            placeholder="Search SKU, Title, or Region..." 
            className="bg-white/5 border border-white/10 rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-ps-blue w-64"
          />
        </div>
      </div>

      <div className="glass-panel rounded-xl overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-white/5 text-[10px] uppercase tracking-widest text-gray-500 font-mono">
              <th className="px-6 py-4">ID</th>
              <th className="px-6 py-4">Game Title</th>
              <th className="px-6 py-4">Inventory</th>
              <th className="px-6 py-4">Active Rentals</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {catalog.map(game => (
              <tr key={game.id} className="hover:bg-white/5 transition-colors group">
                <td className="px-6 py-4 font-mono text-xs text-gray-400">{game.id}</td>
                <td className="px-6 py-4 font-bold text-sm">{game.title}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{game.stock}</span>
                    <div className="w-20 h-1 bg-gray-800 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${game.stock < 50 ? 'bg-red-500' : 'bg-ps-blue'}`} 
                        style={{ width: `${Math.min(100, (game.stock / 500) * 100)}%` }} 
                      />
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm">{game.rentals}</td>
                <td className="px-6 py-4">
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-tighter ${
                    game.status === 'Low Stock' ? 'bg-red-500/20 text-red-400' :
                    game.status === 'High Demand' ? 'bg-ps-blue/20 text-ps-blue' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    {game.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="p-2 hover:bg-ps-blue/20 rounded-lg text-gray-500 hover:text-ps-blue transition-colors">
                    <ChevronRight size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen w-full bg-ps-dark text-white font-sans selection:bg-ps-blue selection:text-white">
      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 flex flex-col p-6 gap-8 shrink-0">
        <div className="flex items-center gap-3 px-2">
          <div className="w-10 h-10 bg-ps-blue rounded-xl flex items-center justify-center shadow-lg shadow-ps-blue/20">
            <Disc className="text-white" size={24} />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">PSX HUB</h1>
            <p className="text-[10px] text-gray-500 font-mono tracking-widest">MANAGEMENT v4.2</p>
          </div>
        </div>

        <nav className="flex flex-col gap-2">
          <p className="text-[10px] text-gray-600 font-mono uppercase tracking-widest px-2 mb-2">Main Menu</p>
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <SidebarItem icon={Globe} label="System Health" active={activeTab === 'health'} onClick={() => setActiveTab('health')} />
          <SidebarItem icon={Database} label="Catalog" active={activeTab === 'catalog'} onClick={() => setActiveTab('catalog')} />
          <SidebarItem icon={Package} label="Inventory" active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} />
          <SidebarItem icon={Users} label="Accounts" active={activeTab === 'users'} onClick={() => setActiveTab('users')} />
        </nav>

        <div className="mt-auto">
          <div className="glass-panel p-4 rounded-xl mb-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-[10px] font-mono text-gray-400 uppercase">Gateway Online</span>
            </div>
            <p className="text-[10px] text-gray-600 font-mono">Region: Asia-East1</p>
            <p className="text-[10px] text-gray-600 font-mono">Latency: 12ms</p>
          </div>
          <SidebarItem icon={Settings} label="Settings" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-10 shrink-0">
          <div className="flex items-center gap-4">
            <div className="flex -space-x-2">
              {[1, 2, 3].map(i => (
                <div key={i} className="w-8 h-8 rounded-full border-2 border-ps-dark bg-gray-800 flex items-center justify-center text-[10px] font-bold">
                  {String.fromCharCode(64 + i)}
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-500 font-mono">3 Admins Active</p>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end">
              <p className="text-sm font-bold">Udayasri Madushan</p>
              <p className="text-[10px] text-ps-blue font-mono uppercase tracking-widest">System Architect</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-ps-blue to-ps-accent p-[1px]">
              <div className="w-full h-full rounded-xl bg-ps-dark flex items-center justify-center overflow-hidden">
                <img src="https://picsum.photos/seed/user/100/100" alt="Avatar" className="w-full h-full object-cover opacity-80" />
              </div>
            </div>
          </div>
        </header>

        {/* Viewport */}
        <div className="flex-1 p-10 overflow-hidden">
          {loading ? (
            <div className="h-full w-full flex flex-col items-center justify-center gap-4">
              <div className="w-12 h-12 border-4 border-ps-blue border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-mono text-gray-500 uppercase tracking-widest animate-pulse">Synchronizing Microservices...</p>
            </div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="h-full"
              >
                {activeTab === 'dashboard' && renderDashboard()}
                {activeTab === 'health' && renderSystemHealth()}
                {activeTab === 'catalog' && renderCatalog()}
                {activeTab !== 'dashboard' && activeTab !== 'health' && activeTab !== 'catalog' && (
                  <div className="h-full flex flex-col items-center justify-center text-gray-600">
                    <Settings size={48} className="mb-4 opacity-20" />
                    <p className="text-lg font-bold uppercase tracking-widest">Module Under Development</p>
                    <p className="text-xs font-mono mt-2">Accessing Restricted Microservice Domain...</p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          )}
        </div>
      </main>
    </div>
  );
}
