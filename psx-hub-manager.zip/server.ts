import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Mock Data Generators
  const generateServices = () => {
    const languages = ["Go", "Rust", "Java", "Python", "Node.js", "C++", "Scala", "C", "Zig", "Kotlin"];
    const domains = ["Catalog", "Inventory", "Orders", "Fulfillment", "Rentals", "Users", "Licensing", "Pricing", "Analytics", "Partner"];
    
    return Array.from({ length: 1000 }, (_, i) => {
      const id = `svc-${i.toString().padStart(4, '0')}`;
      // Generate 2-5 random dependencies from the 1000 services
      const depCount = Math.floor(Math.random() * 4) + 2;
      const dependencies = Array.from({ length: depCount }, () => {
        const depIdx = Math.floor(Math.random() * 1000);
        return `svc-${depIdx.toString().padStart(4, '0')}`;
      }).filter(d => d !== id); // Avoid self-dependency

      return {
        id,
        name: `${domains[i % domains.length].toLowerCase()}-${languages[i % languages.length].toLowerCase()}-${i}`,
        domain: domains[i % domains.length],
        language: languages[i % languages.length],
        status: Math.random() > 0.02 ? "healthy" : Math.random() > 0.5 ? "degraded" : "down",
        latency: Math.floor(Math.random() * 150) + 10,
        uptime: (99 + Math.random()).toFixed(2),
        dependencies
      };
    });
  };

  const games = [
    { id: "G-001", title: "The Last of Us Part II", stock: 450, rentals: 120, status: "In Stock" },
    { id: "G-002", title: "God of War Ragnarök", stock: 890, rentals: 340, status: "High Demand" },
    { id: "G-003", title: "Horizon Forbidden West", stock: 210, rentals: 85, status: "In Stock" },
    { id: "G-004", title: "Ghost of Tsushima", stock: 15, rentals: 190, status: "Low Stock" },
    { id: "G-005", title: "Gran Turismo 7", stock: 300, rentals: 45, status: "In Stock" },
    { id: "G-006", title: "Ratchet & Clank: Rift Apart", stock: 120, rentals: 30, status: "In Stock" },
  ];

  // API Routes
  app.get("/api/system/health", (req, res) => {
    res.json(generateServices());
  });

  app.get("/api/catalog", (req, res) => {
    res.json(games);
  });

  app.get("/api/stats", (req, res) => {
    res.json({
      totalDiscs: 145200,
      activeRentals: 12400,
      warehouseUtilization: "78%",
      activeServices: 982,
      degradedServices: 14,
      downServices: 4
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`PSX Hub Manager running on http://localhost:${PORT}`);
  });
}

startServer();
